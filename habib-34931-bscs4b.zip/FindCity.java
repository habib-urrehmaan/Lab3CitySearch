/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package findcity;

import com.opencsv.CSVReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.*;

/**
 *
 * @author DELL
 */
public class FindCity {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
      //csv file containing data
      CSVReader reader = new CSVReader(new FileReader("E:\\Study\\semester5\\AdvanceProg\\labs\\GeoLiteCity-Location.csv"), ',' , '"' , 1);
       
      //Read CSV line by line and use the string array as you want
      //Read all rows at once
  
       
      //Read CSV line by line and use the string array as you want
      String[] nextLine;
      double lat=0;
      double longitude;
      boolean count=false; 
      HashMap<Double,String> longCity=new HashMap<Double,String>();
      HashMap<Double,HashMap<Double,String>> CityMap = new HashMap<Double,HashMap<Double,String>>();
      
      while ((nextLine = reader.readNext()) != null) {
          //System.out.println(lat);
         if (nextLine != null && count) {
            //Verifying the read data here
            //System.out.println(Arrays.toString(nextLine));
            //System.out.println(nextLine[3]);
            lat=Double.parseDouble(nextLine[5]);
            
            longitude=Double.parseDouble(nextLine[6]);
            longCity.put(longitude,nextLine[3]);
            CityMap.put(lat,longCity);
            //System.out.println(lat);
            //System.out.println(longitude);
         }
         count=true;
       }
      System.out.println(CityMap.get(-33.9258).get(18.4232));
      int num=0;
      int opt=0;
      int i=0;
      String CityName;
      System.out.println("User Please Enter Number of Cities to Search");
      Scanner input=new Scanner(System.in);
      num=input.nextInt();
      
      while (i<num)
      {
          System.out.println("1.Get Longitude and Latitude");
          System.out.println("2.Get CityName");
          opt=input.nextInt();
          
          switch (opt)
                  {
                      case 1:
                          System.out.println("Enter Name of City");
                          Scanner enter=new Scanner(System.in);
                          CityName=enter.nextLine();
                          
                          for (Map.Entry<Double, HashMap<Double, String>> e : CityMap.entrySet()) {
                            Double key = e.getKey();
                            
                            HashMap<Double, String> value = e.getValue();
                            if (value.containsValue(CityName))
                                System.out.println("Latitude:"+key+"longitude:");
                             }
          
                          break;
                      case 2:
                          double lng,latit;
                          System.out.println("Enter Longitude");
                          lng=input.nextDouble();
                          System.out.println("Enter Latitude");
                          latit=input.nextDouble();
                          break;
                      default:
                          System.out.println("Option Entered was wrong");
                          break;
                  }
          i++;
      }
                  
                  }
          //System.out.println("Enter");
      }



